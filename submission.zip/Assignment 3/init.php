<?php
# sets up Words table
    $db = new mysqli('localhost', 'spj916', "cs4501", 'spj916');
    if ($db->connect_error)
       die ("Could not connect to database " . $db->connect_error);
    $query = "drop table Words";
    $db->query($query);
    $result = $db->query(
    	    "create table Words (Id int primary key not null auto_increment, Word char(30) not null)");
    $fileptr = fopen("words5.txt", "r");
    while ($line = fgetss($fileptr, 512)) {
	  $query = "insert into Words (Word) value ('$line')";
	  $db->query($query) or die ("Invalid insert " . $db->error);
    }
    fclose($fileptr);
    header("Location: entername.php");
?>