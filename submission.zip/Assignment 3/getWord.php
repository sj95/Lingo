<?php
   $db = new mysqli('localhost', 'spj916', "cs4501", 'spj916');
   if ($db->connect_error):
      die ("Could not connect to db " . $db->connect_error);
   endif;

   # picks 5 random words and returns them as an array

   $query = "select word from Words order by rand() limit 5";
   $result = $db->query($query);
   $rows = $result->num_rows;
   $arr = array();
   if ($rows >= 1):
      $i = 0;
      while ($row = $result->fetch_row()) {
          $i++;
	  $arr["word$i"] = $row[0];
      }
      echo json_encode($arr);
   else:
      die ("DB Error");
   endif;
?>
