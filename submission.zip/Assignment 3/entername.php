<?php

   # form to get player's name
   
   session_start();
   if (isset($_SESSION["error"])):
      $error = $_SESSION["error"];
      echo $error;
   endif;
?>
<html>
  <b>Welcome to Lingo! Enter your name below.</b>
  <form action = "lingo.php"
	method = "POST">
    <input type = "text" name = "name" size = "45" maxlength = "30">
    <input type = "submit" value = "Enter">
  </form>
</html>
