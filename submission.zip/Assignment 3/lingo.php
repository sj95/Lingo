<?php
    # checks to see if a name was entered
    session_start();
    if (empty($_POST["name"])):
       $_SESSION["error"] = "You did not enter a name.";
       header("Location: entername.php");
    else:
       $name = $_POST["name"];
       setcookie("name", "$name", time()+3600);
    endif;
?>
<html>
  <head>
    <b>Welcome to Lingo, <?php if (isset($_COOKIE["name"])) {echo $_COOKIE["name"]; }	else {echo $_POST["name"]; }  ?></b><br />
    <link rel = "stylesheet" type = "text/css" href = "letterStyle.css"/>
    <script src = "http://code.jquery.com/jquery-latest.js"></script>
    <script type = "text/javascript" language = "javascript">

    // global variables and local storage

    var wordArray = [];
    localStorage.round = "1";
    localStorage.turn = "1";
    localStorage.puzzles = "0";
    localStorage.wins = "0";
    localStorage.totalPuzzles = "0";
    localStorage.totalWins = "0";
    localStorage.roundOver = "1";
    localStorage.puzzleOver = "0";

    // collects group of 5 words from database

    function collectWords() {
        $.post("getWord.php",
	function(data) {
	    if (localStorage.roundOver == "1") {
	    myVar = setTimeout(checkGuess, 10000);
	    arr = $.parseJSON(data);
	    wordArray[0] = arr.word1;
	    wordArray[1] = arr.word2;
	    wordArray[2] = arr.word3;
	    wordArray[3] = arr.word4;
	    wordArray[4] = arr.word5;
	    $("#theTable").append("<tr align = 'center' class = 'regular' id = 'row1'> <td class = 'correct'>" + arr.word1.charAt(0) + "</td><td> </td><td> </td><td> </td><td> </td></tr>");
	    $(".winlose").empty();
	    localStorage.roundOver = "0";
	    }
	    else
		alert("You are already playing Lingo");
	});
    }

    // contains algorithm to determine red, blue, black letters

    function checkGuess() {
    	clearTimeout(myVar);
    	myVar = setTimeout(checkGuess, 10000);
    	round = Number(localStorage.round);
	turn = Number(localStorage.turn);
	puzzles = Number(localStorage.puzzles);
	over = localStorage.roundOver;
	if (turn > 5 || over == "1")
	   alert("Please advance to the next round.");
	else {
        guess = $("input[name=guess]").val();
	style = [];
	used = [];
	correct = 0;
	for (i = 0; i < 5; i++) {
	    style[i] = "wrong";
	    used[i] = 0;
	}
	if (guess.length != 5) {
	   alert("This is an invalid guess");
	   $("#theTable").append("<tr align = 'center' class = 'regular' id = 'row1'> <td></td><td></td><td></td><td></td><td></td></tr>");
	turn++;
	localStorage.turn = turn;
	if (turn > 5) {
	   alert("You have lost this round. The correct word was " + wordArray[puzzles]);
	   puzzles = Number(localStorage.puzzles);
	   puzzles++;
	   localStorage.puzzles = puzzles;
	   puzzles = Number(localStorage.totalPuzzles);
	   puzzles++;
	   localStorage.totalPuzzles = puzzles;
	   localStorage.puzzleOver = "1";
	   } }
	else {
	   i = 0;
	   for (i = 0; i < 5; i++) {
	       if (guess.charAt(i) == wordArray[puzzles].charAt(i)) {
	       	  style[i] = "correct";
		  used[i] = 1;
		  correct++;
	       }
	   }
	   for (i = 0; i < 5; i++) {
	       	  for (j = 0; j < 5; j++) {
		      if (guess.charAt(i) == wordArray[puzzles].charAt(j) && used[j] == 0 && style[i] != "correct") {
		      	 style[i] = "partial";
			 used[j] = 1;
			 j = 5;
		      }
		  }
	   }
	$("#theTable").append("<tr align = 'center' class = 'regular' id = 'row1'> <td class = " + style[0] + ">" + guess[0] + "</td><td class = " + style[1] + ">" + guess[1] + "</td><td class = " + style[2] + ">" + guess[2] + "</td><td class = " + style[3] + ">" + guess[3] + "</td><td class = " + style[4] + ">" + guess[4] + "</td></tr>");
	turn++;
	localStorage.turn = turn;
	if (correct == 5) {
	   alert("Congratulations, you have won this puzzle!");
	   localStorage.turn = "6";
	   puzzles = Number(localStorage.puzzles);
	   puzzles++;
	   localStorage.puzzles = puzzles;
	   wins = Number(localStorage.wins);
	   wins++;
	   localStorage.wins = wins;
	   puzzles = Number(localStorage.totalPuzzles);
	   puzzles++;
	   localStorage.totalPuzzles = puzzles;
	   wins = Number(localStorage.totalWins);
	   wins++;
	   localStorage.totalWins = wins;
	   localStorage.puzzleOver = "1";
	}
	else if (turn > 5) {
	   alert("You have lost this round. The correct word was " + wordArray[puzzles]);
	   puzzles = Number(localStorage.puzzles);
	   puzzles++;
	   localStorage.puzzles = puzzles;
	   puzzles = Number(localStorage.totalPuzzles);
	   puzzles++;
	   localStorage.totalPuzzles = puzzles;
	   localStorage.puzzleOver = "1";
	   }
	} }
    }

    // clears table and moves to next word

    function advance() {
	table = document.getElementById("theTable");
	rows = table.rows.length;
	puzzles = Number(localStorage.puzzles);
	wins = Number(localStorage.wins);
	over = localStorage.puzzleOver;
	if (over == "1") {
	clearTimeout(myVar);
	myVar = setTimeout(checkGuess, 10000);
	localStorage.puzzleOver = "0";
	for (i = 0; i < rows; i++) {
	    table.deleteRow(0);
	}
	localStorage.turn = "1";
	if (wins > 2) {
	   $(".winlose").append("Congratulations, you have won Lingo!");
	   localStorage.roundOver = "1";
	   localStorage.turn = "1";
    	   localStorage.puzzles = "0";
    	   localStorage.wins = "0";
	   round = Number(localStorage.round);
	   round++;
	   localStorage.round = round;
	}
	else if (puzzles > 4) {
	   $(".winlose").append("I'm sorry but you have lost.");
	   localStorage.roundOver = "1";
	   localStorage.turn = "1";
    	   localStorage.puzzles = "0";
    	   localStorage.wins = "0";
	   round = Number(localStorage.round);
	   round++;
	   localStorage.round = round;
	}
	else {
	$("#theTable").append("<tr align = 'center' class = 'regular' id = 'row1'> <td class = 'correct'>" + wordArray[puzzles].charAt(0) + "</td><td> </td><td> </td><td> </td><td> </td></tr>");
	}
	$(".stats").empty();
	$(".stats").append("Total rounds played: " + (Number(localStorage.round) - 1) + "<br />Total puzzles played: " + localStorage.totalPuzzles + "<br />Total puzzles won: " + localStorage.totalWins); }
	else
	    alert("This puzzle is not complete.");
    }
    </script>

    <!-- contains buttons, fields, and divs -->

  </head>
  <body>
    <table id = "theTable" border = "1" class = "thetable"> </table>
    <input type = "submit" value = "Play" onclick = "collectWords()"><br />
    <input type = "text" name = "guess" size = "30">
    <input type = "submit" value = "Enter" onclick = "checkGuess()"><br />
    <input type = "submit" value = "Advance" onclick = "advance()">
    <div class = "stats"></div>
    <div class = "winlose"></div>
  </body>
</html>